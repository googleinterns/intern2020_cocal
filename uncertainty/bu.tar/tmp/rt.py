import os, sys
import numpy as np

import tensorflow as tf

import model
from model.util import *


class Teacher(tf.keras.Model):
    def __init__(self, params, model_base, ld_src, ld_tar, ideal=False):
        super().__init__()
        self.model_base = model_base
        self.ideal = ideal
        if not hasattr(params, 'iw') or params.iw == 'none':
            self.model_conf = getattr(model, params.conf)(self.model_base)
        else:
            model_sd_head = getattr(model, params.iw)(self.model_base.dim_feat, 2, 50*params.n_labels)
            model_sd = model.SourceDisc(self.model_base, model_sd_head)
            model_sd_cal = model.TempCls(model_sd)
            model_iw = model.IW(model_sd_cal)
            self.model_conf = getattr(model, params.conf)(self.model_base, model_iw)
        
        self.ld_src = ld_src # augmentation-enabled dataset
        self.ld_tar = ld_tar # augmentation-enabled dataset


    def __iter__(self):
        self.iter_end = {'src': False, 'tar': False}
        self.iter = {'src': iter(self.ld_src), 'tar': iter(self.ld_tar)}
        return self

    
    def __next__(self):
        ## choose src or tar
        flag_src = np.random.binomial(1, 0.5)
        
        if flag_src:
            ## if source, return samples from the source distribution
            def sample_from_source():
                return next(self.iter['src'])
                
            try:
                x, y = sample_from_source()
            except StopIteration:
                self.iter_end['src'] = True
                
                if self.iter_end['src'] and self.iter_end['tar']:
                    raise StopIteration
                else:
                    x, y = sample_from_source()

        else:
            ## if target, return only a confident example with its pseudo-label
            def sample_from_target():
                while True:
                    x, y = next(self.iter['tar'])
                    y_pred = self.model_base(x)['y_pred']
                    conf = self.model_conf(x) ##TODO: return dict?
                    if any(conf == 1):
                        break
                    
                # print("#conf =", tf.math.reduce_sum(tf.cast(conf==1, tf.float32)),
                #       "precision =", tf.math.reduce_mean(tf.cast(tf.cast(y[conf==1], tf.int64) == tf.cast(y_pred[conf==1], tf.int64), tf.float32)))

                if self.ideal:
                    x, y = x[conf==1], y[conf==1]
                else:
                    x, y = x[conf==1], y_pred[conf==1]

                
                ##TODO: can small examples make some problems?
                return x, y
                
            try:
                x, y = sample_from_target()
            except StopIteration:
                self.iter_end['tar'] = True

                if self.iter_end['src'] and self.iter_end['tar']:
                    raise StopIteration
                else:
                    x, y = sample_from_target()

        return x, y
                    
                
                
