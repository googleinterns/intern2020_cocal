CUDA_VISIBLE_DEVICES=3 python3 main_self.py --exp_name m2m_self_small_0 --data.src MNIST --data.tar MNIST --train.find_best --data.sample_ratio 0.1 0.1 --train_base.find_best
CUDA_VISIBLE_DEVICES=3 python3 main_self.py --exp_name m2m_self_small_1 --data.src MNIST --data.tar MNIST --train.find_best --data.sample_ratio 0.1 0.1 --train_base.find_best
CUDA_VISIBLE_DEVICES=3 python3 main_self.py --exp_name m2m_self_small_2 --data.src MNIST --data.tar MNIST --train.find_best --data.sample_ratio 0.1 0.1 --train_base.find_best
CUDA_VISIBLE_DEVICES=3 python3 main_self.py --exp_name m2m_self_small_3 --data.src MNIST --data.tar MNIST --train.find_best --data.sample_ratio 0.1 0.1 --train_base.find_best
CUDA_VISIBLE_DEVICES=3 python3 main_self.py --exp_name m2m_self_small_4 --data.src MNIST --data.tar MNIST --train.find_best --data.sample_ratio 0.1 0.1 --train_base.find_best
CUDA_VISIBLE_DEVICES=3 python3 main_self.py --exp_name m2m_self_small_5 --data.src MNIST --data.tar MNIST --train.find_best --data.sample_ratio 0.1 0.1 --train_base.find_best
CUDA_VISIBLE_DEVICES=3 python3 main_self.py --exp_name m2m_self_small_6 --data.src MNIST --data.tar MNIST --train.find_best --data.sample_ratio 0.1 0.1 --train_base.find_best
CUDA_VISIBLE_DEVICES=3 python3 main_self.py --exp_name m2m_self_small_7 --data.src MNIST --data.tar MNIST --train.find_best --data.sample_ratio 0.1 0.1 --train_base.find_best
CUDA_VISIBLE_DEVICES=3 python3 main_self.py --exp_name m2m_self_small_8 --data.src MNIST --data.tar MNIST --train.find_best --data.sample_ratio 0.1 0.1 --train_base.find_best
CUDA_VISIBLE_DEVICES=3 python3 main_self.py --exp_name m2m_self_small_9 --data.src MNIST --data.tar MNIST --train.find_best --data.sample_ratio 0.1 0.1 --train_base.find_best


