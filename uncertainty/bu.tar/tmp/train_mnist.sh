mkdir -p snapshots/mnist_ResNet18
CUDA_VISIBLE_DEVICES=4 python3 run_mnist.py --exp_name mnist --tar MNIST > snapshots/mnist_ResNet18/out
