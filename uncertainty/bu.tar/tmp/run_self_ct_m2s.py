CUDA_VISIBLE_DEVICES=2 python3 main_self.py --exp_name m2s_self_ct --data.src MNIST --data.tar SVHN --data.aug svhnspec --train_advtr.load_final
