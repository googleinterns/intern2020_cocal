import os, sys
import time
import numpy as np

import tensorflow as tf
from learning.loss import reg_l2
import model

from learning import LearnerCls, LearnerDACls
from learning import TempScalingCls as CalibratorCls
from learning import LearnerCls, LearnerDACls
from learning import LearnerConfPred


class BaseLearnerRT:
    def __init__(self, params, params_base, params_iw, params_iw_cal, params_conf, model_st, model_rt, params_base_init=None, params_advtr=None, model_name_postfix=''):
        self.params = params
        self.params_base = params_base
        self.params_iw = params_iw
        self.params_iw_cal = params_iw_cal
        self.params_conf = params_conf
        self.params_base_init = params_base_init
        self.params_advtr = params_advtr ##TODO: simplify
        self.model_s = model_st
        self.model_t = model_rt
        self.model = self.model_s.model_base
        self.loss_fn_train = None
        self.loss_fn_val = None
        self.loss_fn_test = None
        self.model_name_postfix = model_name_postfix

        self.model_fn_best = os.path.join(self.params.save_root, 'model_params%s_best'%(self.model_name_postfix))
        self.model_fn_final = os.path.join(self.params.save_root, 'model_params%s_final'%(self.model_name_postfix))

        
    def _load_best(self):
        self.model.load_weights(self.model_fn_best)
        print("[load] the best model is loaded")

        
    def _check_best(self):
        return os.path.exists(self.model_fn_best + '.index')

        
    def _load_final(self):
        self.model.load_weights(self.model_fn_final)
        print("[load] the final model is loaded")


    def _check_final(self):
        return os.path.exists(self.model_fn_final + '.index')
        
        
    def _train_begin(self, ds_src, ds_tar, ds_dom):

        ##TODO: put the initialization in the outside of this learning
        ## initialize a base model
        if self.params.init == 'sourceonly':

            ##TODO: assume classification
            print("## init the student model with sourceonly training")
            model.set_trainable(self.model, True)

            ## init a learner
            learner = LearnerCls(self.params_base_init, self.model, model_name_postfix='_sourceonlyinit')
            ## train the model
            learner.train(ds_src.train, ds_src.val, ds_src.test)
            ## test the model
            learner.test(ds_src.test, ld_name='src', verbose=True)
            print()

        elif self.params.init == 'advtr':
            ##TODO: assume classification
            print("## init a base model with adversarial training")
            model.set_trainable(self.model, True)

            ## init a adv model
            mdl_adv = getattr(model, self.params_advtr.model_advtr)(n_in=self.model.dim_feat)
            ## init a learner
            learner = LearnerDACls(self.params_advtr, model.DAN(self.model, mdl_adv), model_name_postfix='_advtrinit')
            ## train the model
            learner.train([ds_src.train, ds_dom.train], None, ds_tar.test)        
            ## test the model
            learner.test(ds_tar.test, ld_name='tar', verbose=True)
            print()            
            
        else:
            raise NotImplementedError


        ## save the initial model
        #self.error_val, *_ = self.validate(ds_src.val)
        self.error_val = np.inf
        model_fn = os.path.join(self.params.save_root, 'model_params%s_best'%(self.model_name_postfix))
        self.model.save_weights(model_fn)
        ##TODO: what is the best way?
        
    
    def _train_end(self):
        ## save the final model
        model_fn = os.path.join(self.params.save_root, 'model_params%s_final'%(self.model_name_postfix))
        self.model.save_weights(model_fn)
        print("[final model] saved at %s"%(model_fn))

        ## load the best model
        if self.params.load_final:
            self._load_final()
        else:
            self._load_best()

        
    def _train_epoch_begin(self, i_epoch):
        self.t_epoch_begin = time.time()
        self.i_epoch = i_epoch

        ## switch student and teacher
        print("## switch: student <-> teacher")
        self.model_t, self.model_s = self.model_s, self.model_t
        self.model = self.model_s.model_base
        #self._load_best() ## do not call. use old model
        print()
        ##TODO: do I need to load the best one or the last one

        
    def _train_epoch_end(self, i_epoch, ld_val, ld_te=None):
        ## print progress
        msg = "[epoch: %d/%d, %.2f sec]"%(i_epoch, self.params.n_epochs, time.time() - self.t_epoch_begin)
        
        ## print losses
        for k, v, in self.__dict__.items():
            if 'loss' in k and '_fn' not in k:
                msg += '%s = %.4f, '%(k, v)
        
        ## validate the current model
        if i_epoch % self.params.val_period == 0:
            if ld_te is not None:
                error_te, ece_te, ece_oc_te, *_ = self.test(ld_te)
                msg += 'error_test = %.4f, ECE_test = %.2f%% (%.2f%%), '%(error_te, ece_te*100.0, ece_oc_te*100.0)
            error_val, *_ = self.validate(ld_val)
            msg += 'error_val = %.4f (error_val_best = %.4f)'%(error_val, self.error_val)
            
        ## save the best model
        if self.error_val >= error_val:
            self.error_val = error_val
            model_fn = os.path.join(self.params.save_root, 'model_params%s_best'%(self.model_name_postfix))
            self.model.save_weights(model_fn)
            msg += ', saved!'

        print(msg)

        
    def _train_epoch(self, ds_src, ds_tar, ds_dom):

        ## 1. learn IW
        if self.model_t.train.model_conf.model_iw is not None:
            print("## learn IW")
            model_sd = self.model_t.train.model_conf.model_iw.model_sd.model
            model_sd.train()

            ## init a learner
            learner_sd = LearnerCls(self.params_iw, model_sd, model_name_postfix='_iw_epoch_%d'%(self.i_epoch))
            ## train the model
            learner_sd.train(ds_dom.train, ds_dom.val, ds_dom.test)
            ## test the model
            learner_sd.test(ds_dom.test, ld_name='domain', verbose=True)
            print()

            ## init a calibraton model
            model_sd_cal = self.model_t.train.model_conf.model_iw.model_sd
            model_sd_cal.train()

            ## init a calibrator
            calibrator_iw = CalibratorCls(self.params_iw_cal, model_sd_cal, model_name_postfix='_iw_cal_epoch_%d'%(self.i_epoch))
            ## calibrate the model
            calibrator_iw.train(ds_dom.val, ds_dom.val, ds_dom.test)
            ## test the model
            calibrator_iw.test(ds_dom.test, ld_name='domain', verbose=True)
            print()

            ## 2. learn confidence predictor
            model_base = self.model_t.train.model_base
            model_conf = self.model_t.train.model_conf
            model_iw = self.model_t.train.model_conf.model_iw
            model_iw_cond = model.CondIW(model_iw, model_conf, ds_src.train, ds_tar.train)
            ## init a learner
            learner = LearnerConfPred(self.params_conf, model_conf, model_base, model_iw_cond, model_name_postfix='_confpred_epoch_%d'%(self.i_epoch))
            ## train the model
            learner.train(ds_src.val, ds_src.val, ds_tar.test)
            ## test the model
            learner.test(ds_tar.test, ld_name='tar', verbose=True)
            learner.test(ds_tar.train, ld_name='tar (train)', verbose=True)
            print()
        else:
            model_base = self.model_t.train.model_base
            model_conf = self.model_t.train.model_conf
            
            ## init a learner
            learner = LearnerConfPred(self.params_conf, model_conf, model_base, None, model_name_postfix='_confpred_epoch_%d'%(self.i_epoch))
            ## train the model
            model_conf.T = tf.Variable(1.0 - self.params_conf.eps) ##TODO
            print("T = %f"%(model_conf.T.numpy()))
            ## test the model
            learner.test(ds_tar.test, ld_name='tar', verbose=True)
            learner.test(ds_tar.train, ld_name='tar (train)', verbose=True)
            
        
        ## 3. learn the base model using the reliable teacher
        model.set_trainable(self.model, True)
        ## init a learner
        learner = LearnerCls(self.params_base, self.model, model_name_postfix='_epoch_%d'%(self.i_epoch))
        ## train the model
        learner.train(self.model_t.train, self.model_t.val, ds_tar.test)
        ## test the model
        learner.test(ds_tar.test, ld_name='tar', verbose=True)
        print()

        ## 4. calibrate the base model using the reliable teacher


        
    def train(self, ds_src, ds_tar, ds_dom):

        if not self.params.rerun and self._check_final():
            if self.params.load_final:
                self._load_final()
            else:
                self._load_best()
            return

        self._train_begin(ds_src, ds_tar, ds_dom)
        for i in range(1, self.params.n_epochs+1):
            self._train_epoch_begin(i)
            self._train_epoch(ds_src, ds_tar, ds_dom)
            self._train_epoch_end(i, self.model_t.val, ds_tar.test)
        self._train_end()
            
        
    def validate(self, ld_val):
        return self.test(ld_val, loss_fn=self.loss_fn_val)

    
    def test(self, ld_te, loss_fn=None):
        loss_fn = self.loss_fn_test if loss_fn is None else loss_fn
        loss_vec = []
        
        for x, y in ld_te:
            loss_dict = loss_fn(x, y,
                                model=lambda x: self.model(x, training=False),
                                reduce='none')
            loss_vec.append(loss_dict['loss'])
        loss = tf.math.reduce_mean(tf.concat(loss_vec, 0))
        return loss

            
        
