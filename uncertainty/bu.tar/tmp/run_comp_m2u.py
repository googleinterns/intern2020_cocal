I_EXP = 0
CUDA_VISIBLE_DEVICES=0 python3 main_srconly.py --exp_name m2u_srconly_comp_$I_EXP --src MNIST --tar USPS --aug svhnspec --train.find_best 
CUDA_VISIBLE_DEVICES=1 python3 main_advtr.py --exp_name m2u_advtr_comp_$I_EXP --src MNIST --tar USPS --aug svhnspec --train.find_best --train.load_final --merge_train_val
CUDA_VISIBLE_DEVICES=2 python3 main_rt.py --exp_name m2u_self_comp_$I_EXP --data.src MNIST --data.tar USPS --data.aug svhnspec --train.find_best --train_advtr.find_best --train_advtr.load_final --train_base.find_best --model.iw none
CUDA_VISIBLE_DEVICES=3 python3 main_rt.py --exp_name m2u_rt_comp_$I_EXP --data.src MNIST --data.tar USPS --data.aug svhnspec --train.find_best --train_advtr.find_best --train_advtr.load_final --train_iw.find_best --cal_iw.find_best --train_base.find_best --est_conf.find_best
