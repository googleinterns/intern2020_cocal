CUDA_VISIBLE_DEVICES=0 python3 main_rt.py --exp_name m2s_rt --data.src MNIST --data.tar SVHN --train.find_best --train_advtr.load_final --data.aug svhnspec --train_base.find_best
CUDA_VISIBLE_DEVICES=1 python3 main_rt.py --exp_name m2s_self --data.src MNIST --data.tar SVHN --train.find_best --train_advtr.load_final --data.aug svhnspec --train_base.find_best --model.iw none

CUDA_VISIBLE_DEVICES=2 python3 main_advtr.py --exp_name m2s_advtr --src MNIST --tar SVHN --train.advtr_type DANN --train.find_best --aug svhnspec
CUDA_VISIBLE_DEVICES=3 python3 main_self.py --exp_name m2s_self --data.src MNIST --data.tar SVHN --train.find_best --train_base.find_best --aug svhnspec
