CUDA_VISIBLE_DEVICES=0 python3 main_self.py --exp_name m2u_self_ct --data.src MNIST --data.tar USPS --data.aug svhnspec --train_advtr.load_final
