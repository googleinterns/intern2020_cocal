import os, sys
import time

import numpy as np
import tensorflow as tf

from learning import BaseLearnerRT
from learning import loss_xe, loss_01, loss_xe_adv, loss_entropy
from uncertainty import ECE, plot_acc_rank, plot_acc_conf

class LearnerClsRT(BaseLearnerRT):
    
    def __init__(self, params, params_base, params_iw, params_iw_cal, params_conf, model_st, model_rt, params_base_init=None, params_advtr=None, model_name_postfix=''):
        super().__init__(params, params_base, params_iw, params_iw_cal, params_conf, model_st, model_rt, params_base_init=params_base_init, params_advtr=params_advtr, model_name_postfix=model_name_postfix)
        self.loss_fn_train = loss_xe
        self.loss_fn_val = loss_01
        self.loss_fn_test = loss_01


    def test(self, ld_te, loss_fn=None, ld_name='', verbose=False):
        error = super().test(ld_te, loss_fn=loss_fn)
        nll = super().test(ld_te, loss_fn=loss_xe)
              
        ## compute calibration error
        log_ph_list, ph_list, yh_list, y_list = [], [], [], []
        for x, y in ld_te:
            logits = self.model(x, training=False)['logits']

            log_ph = tf.math.reduce_max(tf.nn.log_softmax(tf.cast(logits, tf.float64), -1), -1) # use log/float64 to avoid tie in sorting due to numerical error
            ph = tf.math.reduce_max(tf.nn.softmax(logits, -1), -1)
            yh = tf.math.argmax(logits, -1)
            log_ph_list.append(log_ph.numpy())
            ph_list.append(ph.numpy())
            yh_list.append(yh.numpy())
            y_list.append(y.numpy())
        log_ph_list = np.concatenate(log_ph_list)
        ph_list = np.concatenate(ph_list)
        yh_list = np.concatenate(yh_list)
        y_list = np.concatenate(y_list)
        ece, ece_oc = ECE(ph_list, yh_list, y_list,
                          overconf=True,
                          rel_diag_fn=os.path.join(self.params.save_root, 'rel_diag_%s%s'%(ld_name, self.model_name_postfix)) if verbose else None)
        if verbose:
            print('[test%s] cls error = %.2f%%, NLL = %f, ECE = %.2f%% (%.2f%%)'%(
                ld_name if ld_name is '' else ' on %s'%(ld_name),
                error*100.0, nll,ece*100.0, ece_oc*100.0))

            ## plot the accuracy-ranking curve
            plot_acc_rank((yh_list==y_list).astype(np.float32), log_ph_list, fn=os.path.join(self.params.save_root, 'acc_rank_zoom_%s%s'%(ld_name, self.model_name_postfix)))
            plot_acc_rank((yh_list==y_list).astype(np.float32), log_ph_list, fn=os.path.join(self.params.save_root, 'acc_rank_%s%s'%(ld_name, self.model_name_postfix)), ratio=1.0)

            ## plot theh acccuracy-confidence curve
            plot_acc_conf((y_list==yh_list).astype(np.float32), np.exp(log_ph_list), fn=os.path.join(self.params.save_root, 'acc_conf_%s%s'%(ld_name, self.model_name_postfix)))


        return error, ece, ece_oc
