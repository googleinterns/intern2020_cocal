import os, sys
import time
import numpy as np

import tensorflow as tf
from learning.loss import reg_l2
import model

from learning import LearnerCls, LearnerDACls
from learning import TempScalingCls as CalibratorCls


class BaseSelfTraining:
    def __init__(self, params, params_base, params_cal, model_s, model_t, model_name_postfix='', ideal=False):
        self.params = params
        self.params_base = params_base
        self.params_base_cal = params_cal
        self.model = model_s.model_base
        self.model_s = model_s
        self.model_t = model_t
        self.loss_fn_train = None
        self.loss_fn_val = None
        self.loss_fn_test = None
        self.model_name_postfix = model_name_postfix
        self.ideal = ideal

        self.out_dict = {}


    def _load_best(self):
        model_fn = os.path.join(self.params.save_root, 'model_params%s_best'%(self.model_name_postfix))
        self.model.load_weights(model_fn)
        print("[load] the best model is loaded")

        
    def _load_final(self):
        model_fn = os.path.join(self.params.save_root, 'model_params%s_final'%(self.model_name_postfix))
        self.model.load_weights(model_fn)
        print("[load] the final model is loaded")

        
    def _train_begin(self, ds_src, ds_tar, ds_dom):
        
        ## initialize a teacher model
        if self.params.init == 'sourceonly':

            ##TODO: assume classification
            print("## init the teacher model with sourceonly training")
            model_t = self.model_t.model_base
            model.set_trainable(model_t.model, True)

            ## init a learner
            learner = LearnerCls(self.params_base, model_t.model, model_name_postfix='_sourceonlyinit')
            ## train the model
            learner.train(ds_src.train, ds_src.val, ds_src.test)
            ## test the model
            learner.test(ds_src.test, ld_name='src', verbose=True)
            print()

            if self.params.cal:
                print("## calibrate the initialized teacher model via source-only")
                model_t.train()
                ## init a calibrator
                calibrator = CalibratorCls(self.params_base_cal, model_t, model_name_postfix='_sourceonlyinit_cal')
                ## calibrate the model
                calibrator.train(ds_src.val, ds_src.val, ds_tar.test)
                ## test the model
                calibrator.test(ds_src.test, ld_name='src', verbose=True)
                print()
        else:
            raise NotImplementedError

        
        ## save the initial student model
        self.error_val, *_ = self.validate(ds_src.val)
        model_fn = os.path.join(self.params.save_root, 'model_params%s_best'%(self.model_name_postfix))
        self.model.save_weights(model_fn)

    
    def _train_end(self):
        ## save the final model
        model_fn = os.path.join(self.params.save_root, 'model_params%s_final'%(self.model_name_postfix))
        self.model.save_weights(model_fn)
        print("[final model] saved at %s"%(model_fn))

        ## load the best model
        if self.params.load_final:
            self._load_final()
        else:
            self._load_best()

        
    def _train_epoch_begin(self, i_epoch):
        self.i_epoch = i_epoch
        self.t_epoch_begin = time.time()
                

    def _train_epoch_end(self, i_epoch, ld_val, ld_te=None):
        ## print progress
        msg = "[epoch: %d/%d, %.2f sec] "%(i_epoch, self.params.n_epochs, time.time() - self.t_epoch_begin)
        
        ## print losses
        for k, v, in self.__dict__.items():
            if 'loss' in k and '_fn' not in k:
                msg += '%s = %.4f, '%(k, v)
        
        ## validate the current model
        if i_epoch % self.params.val_period == 0:
            if ld_te is not None:
                ##TODO: assume classification
                error_te, ece_te, ece_oc_te, *_ = self.test(ld_te)
                msg += 'error_test = %.2f%%, ECE_test = %.2f%% (%.2f%%), '%(error_te*100.0, ece_te*100.0, ece_oc_te*100.0)
            error_val, *_ = self.validate(ld_val)
            msg += 'error_val = %.4f (error_val_best = %.4f)'%(error_val, self.error_val)
            
        ## save the best model
        if self.error_val >= error_val:
            self.error_val = error_val
            model_fn = os.path.join(self.params.save_root, 'model_params%s_best'%(self.model_name_postfix))
            self.model.save_weights(model_fn)
            msg += ', saved!'

        print(msg)

        ## switch student and teacher
        print("## switch: student <-> teacher")
        self.model_t, self.model_s = self.model_s, self.model_t
        self.model = self.model_s.model_base
        #self._load_best()
        print("do not load the best")

        
    def _train_epoch(self, ds_src, ds_tar, ds_dom):

        ## 1. use a default confidence predictor        
        ## 2. learn the student using the teacher
        model.set_trainable(self.model, True)

        print("## train the student using the teacher")
        ## init a learner
        learner = LearnerCls(self.params_base, self.model.model, model_name_postfix='_epoch_%d'%(self.i_epoch))
        ## train the model
        learner.train(self.model_t.train, self.model_t.val if not self.ideal else ds_tar.val, ds_tar.test)
        ## test the model
        learner.test(ds_tar.test, ld_name='tar', verbose=True)
        print()

        ## 3. calibrate a base model using the teacher
        if self.params.cal:
            print("## calibrate the student using the teacher")
            self.model.train()
            ## init a calibrator
            calibrator = CalibratorCls(self.params_base_cal, self.model, model_name_postfix='_cal')
            ## calibrate the model
            calibrator.train(self.model_t.val, self.model_t.val if not self.ideal else ds_tar.val, ds_tar.test)
            ## test the model
            calibrator.test(ds_tar.test, ld_name='tar', verbose=True)
            print()

        
    def train(self, ds_src, ds_tar, ds_dom):
        #ld_tr, ld_val, ld_te=None):

        
        if not self.params.find_best:
            if self.params.load_final:
                self._load_final()
            else:
                self._load_best()
            return

        self._train_begin(ds_src, ds_tar, ds_dom)
        for i in range(1, self.params.n_epochs+1):
            self._train_epoch_begin(i)
            self._train_epoch(ds_src, ds_tar, ds_dom)
            self._train_epoch_end(i, self.model_t.val, ds_tar.test)
        self._train_end()
            
        
    def validate(self, ld_val):
        return self.test(ld_val, loss_fn=self.loss_fn_val)

    
    def test(self, ld_te, loss_fn=None):
        loss_fn = self.loss_fn_test if loss_fn is None else loss_fn
        loss_vec = []
        
        for x, y in ld_te:
            loss_dict = loss_fn(x, y,
                                model=lambda x: self.model(x, training=False),
                                reduce='none')
            loss_vec.append(loss_dict['loss'])
        loss = tf.math.reduce_mean(tf.concat(loss_vec, 0))
        return loss

            
        
