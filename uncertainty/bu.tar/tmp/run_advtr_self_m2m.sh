screen -dm bash -c "CUDA_VISIBLE_DEVICES=1 python3 main.py --exp_name m2m_sourceonly_small --src MNIST --tar MNIST --train.advtr_type none --train.find_best --cheatkey --model SmallCNN --train.lr 0.01 --train.reg_param_adv 1.0 --train.schedule_reg_param_adv --sample_ratio 0.1 0.1"

screen -dm bash -c "CUDA_VISIBLE_DEVICES=2 python3 main.py --exp_name m2m_advtr_1d0_small --src MNIST --tar MNIST --train.advtr_type DANN --train.find_best --cheatkey --model SmallCNN --train.lr 0.01 --train.reg_param_adv 1.0 --train.schedule_reg_param_adv --sample_ratio 0.1 0.1"

screen -dm bash -c "CUDA_VISIBLE_DEVICES=3 python3 main_self.py --exp_name m2m_self_small --data.src MNIST --data.tar MNIST --train.find_best --model.base SmallCNN --data.sample_ratio 0.1 0.1"


