for i in {0..4}
do
    CUDA_VISIBLE_DEVICES=6 python3 main.py --exp_name summary_m2s_self_$i --data.src MNIST --data.tar SVHN --data.aug svhnspec --training_type self
done
