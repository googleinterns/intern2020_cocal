screen -dm bash -c "CUDA_VISIBLE_DEVICES=1 python3 main.py --exp_name m2svhn --src MNIST --tar SVHN --train.load_best"
screen -dm bash -c "CUDA_VISIBLE_DEVICES=2 python3 main.py --exp_name mus2svhn --src MNIST USPS SynDigit --tar SVHN --train.load_best"
screen -dm bash -c "CUDA_VISIBLE_DEVICES=3 python3 main.py --exp_name m2svhn_aug --src MNIST --tar SVHN --aug svhnspec --train.load_best"
screen -dm bash -c "CUDA_VISIBLE_DEVICES=4 python3 main.py --exp_name mus2svhn_aug --src MNIST USPS SynDigit --tar SVHN --aug svhnspec --train.load_best"
