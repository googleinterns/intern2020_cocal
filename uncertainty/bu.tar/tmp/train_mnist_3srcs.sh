mkdir -p snapshots/mnist_ResNet18
CUDA_VISIBLE_DEVICES=5 python3 run_mnist.py --exp_name mnist_src_3 --n_srcs 3 --tar MNIST > snapshots/mnist_ResNet18/out
