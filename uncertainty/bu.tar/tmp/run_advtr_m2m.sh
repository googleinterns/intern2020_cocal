CUDA_VISIBLE_DEVICES=2 python3 main_advtr.py --exp_name m2m_advtr_small_0 --src MNIST --tar MNIST --train.advtr_type DANN --train.find_best --cheatkey --sample_ratio 0.1 0.1
CUDA_VISIBLE_DEVICES=2 python3 main_advtr.py --exp_name m2m_advtr_small_1 --src MNIST --tar MNIST --train.advtr_type DANN --train.find_best --cheatkey --sample_ratio 0.1 0.1
CUDA_VISIBLE_DEVICES=2 python3 main_advtr.py --exp_name m2m_advtr_small_2 --src MNIST --tar MNIST --train.advtr_type DANN --train.find_best --cheatkey --sample_ratio 0.1 0.1
CUDA_VISIBLE_DEVICES=2 python3 main_advtr.py --exp_name m2m_advtr_small_3 --src MNIST --tar MNIST --train.advtr_type DANN --train.find_best --cheatkey --sample_ratio 0.1 0.1
CUDA_VISIBLE_DEVICES=2 python3 main_advtr.py --exp_name m2m_advtr_small_4 --src MNIST --tar MNIST --train.advtr_type DANN --train.find_best --cheatkey --sample_ratio 0.1 0.1
CUDA_VISIBLE_DEVICES=2 python3 main_advtr.py --exp_name m2m_advtr_small_5 --src MNIST --tar MNIST --train.advtr_type DANN --train.find_best --cheatkey --sample_ratio 0.1 0.1
CUDA_VISIBLE_DEVICES=2 python3 main_advtr.py --exp_name m2m_advtr_small_6 --src MNIST --tar MNIST --train.advtr_type DANN --train.find_best --cheatkey --sample_ratio 0.1 0.1
CUDA_VISIBLE_DEVICES=2 python3 main_advtr.py --exp_name m2m_advtr_small_7 --src MNIST --tar MNIST --train.advtr_type DANN --train.find_best --cheatkey --sample_ratio 0.1 0.1
CUDA_VISIBLE_DEVICES=2 python3 main_advtr.py --exp_name m2m_advtr_small_8 --src MNIST --tar MNIST --train.advtr_type DANN --train.find_best --cheatkey --sample_ratio 0.1 0.1
CUDA_VISIBLE_DEVICES=2 python3 main_advtr.py --exp_name m2m_advtr_small_9 --src MNIST --tar MNIST --train.advtr_type DANN --train.find_best --cheatkey --sample_ratio 0.1 0.1

