ROOT="snapshots/to_svhn_ResNet18"
mkdir -p $ROOT
CUDA_VISIBLE_DEVICES=6 python3 main.py --exp_name to_svhn --src MNIST USPS SynDigit --tar SVHN > $ROOT/out
