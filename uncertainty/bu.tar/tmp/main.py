import os, sys
import argparse

import tensorflow as tf

import data
import model 
from util import *
from learning import LearnerCls, LearnerDACls
from learning import TempScalingCls as CalibratorCls

##TODO: clean-up tf options
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

#gpus = tf.config.experimental.list_physical_devices('GPU')
#tf.config.experimental.set_memory_growth(gpus[0], True)


def main(args):

    ## init a snapshot path
    os.makedirs(args.train.save_root, exist_ok=True)

    ## init logger
    sys.stdout = Logger(os.path.join(args.train.save_root, 'out'))

    ## print args
    print_args(args)

    ## init gpus
    if not args.cpu:
        print("##GPUs Available: ", len(tf.config.experimental.list_physical_devices('GPU')))
        print()

    ## init datasets
    print("## init datasets")
    ds_src = data.MultiSourceDataset(args.src, args.aug_params, batch_size=args.batch_size, val_shuffle=True, val_aug=True, domain_id=1,
                                     color=False if args.img_size[2]==1 else True, size=args.img_size[0], sample_ratio=args.sample_ratio[0])
    ds_tar = getattr(data, args.tar)(root=os.path.join('data', args.tar.lower()), batch_size=args.batch_size, val_shuffle=True, domain_id=0,
                                     color=False if args.img_size[2]==1 else True, size=args.img_size[0], sample_ratio=args.sample_ratio[1])
    ds_dom = data.DomainDataset(ds_src, ds_tar)
    print()
    

    ####
    ## base model learning
    ####
    print('## base model learning')
    ## init a base model
    mdl = getattr(model, args.model)(num_class=args.n_labels, activation='relu', input_shape=args.img_size) ##TODO: generalize
    if args.train.advtr_type == 'none':
        ## init a learner
        learner = LearnerCls(args.train, mdl)
        ## train the model
        learner.train(ds_src.train, ds_src.val, ds_tar.test)
    else:
        ## init a adv model
        mdl_adv = getattr(model, args.model_adv)(n_in=mdl.dim_feat)
        ## init a learner
        learner = LearnerDACls(args.train, model.DAN(mdl, mdl_adv))
        ## train the model
        learner.train([ds_src.train, ds_dom.train], ds_tar.val if args.cheatkey else ds_src.val, ds_tar.test)
        
    ## test the model
    learner.test(ds_tar.test, ld_name=args.tar, verbose=True)
    learner.test(ds_src.test, ld_name='src', verbose=True)
    print()


    sys.exit()

    
    ####
    ## IW learning
    ####
    mdl_iw = None
    if args.iw:
        print('## IW learning')
        
        if args.iw_type == 'srcdisc' or args.iw_type == 'onehidsrcdisc':
            ## init a base model
            if args.iw_type == 'srcdisc':
                mdl_sd = model.SourceDisc(mdl=mdl)
            elif args.iw_type == 'onehidsrcdisc':
                mdl_sd = model.OneHiddenSourceDisc(mdl=mdl)

            ## init a learner
            learner_sd = LearnerCls(args.train_iw, mdl_sd, model_name_postfix='_iw')
            ## train the model
            learner_sd.train(ds_dom.train, ds_dom.val, ds_dom.test)
            ## test the model
            learner_sd.test(ds_dom.test, ld_name='joint', verbose=True)
            print()

            ## init a calibraton model
            mdl_sd_cal = model.TempCls(mdl_sd)
            ## init a calibrator
            calibrator_iw = CalibratorCls(args.cal_iw, mdl_sd_cal, model_name_postfix='_iw_cal')
            ## calibrate the model
            calibrator_iw.train(ds_dom.val, ds_dom.val, ds_dom.test)
            ## test the model
            calibrator_iw.test(ds_dom.test, ld_name='joint', verbose=True)
            print()

            mdl_iw = model.IW(mdl_sd_cal)
            
        elif args.iw_type == 'mmd':
            mdl_mmd = model.GaussianBiasedMMD(mdl, ds_tar.val, sigma=1.0) ##TODO: ds_tar.train
            mdl_iw = model.IW(mdl_mmd, iw_type='mmd')
            ##TODO: no calibration
            
        else:
            raise NotImplementedError

        
    ####
    ## model calibration over labeled source examples and unlabeled target examples
    ####
    print('## model calibration')
    ## init a calibraton model
    mdl_cal = model.TempCls(mdl)
    ## init a calibrator
    calibrator = CalibratorCls(args.cal, mdl_cal, model_iw=mdl_iw, model_name_postfix='_wcal%s'%('' if args.iw_type == 'srcdisc' else args.iw_type) if args.iw else '_cal')
    ## calibrate the model
    calibrator.train(ds_src.val, ds_src.val, ds_tar.test)
    ## test the model
    calibrator.test(ds_tar.test, ld_name=args.tar, verbose=True)
    calibrator.test(ds_src.test, ld_name='srcs', verbose=True)
    print()
    
    ####
    ## model calibration over labeled target examples (best performance)
    ####
    print('## model calibration lower bound')
    ## init a calibraton model
    mdl_cal_lower = model.TempCls(mdl)
    ## init a calibrator
    calibrator = CalibratorCls(args.cal, mdl_cal_lower, model_name_postfix='_cal_lower')
    ## calibrate the model
    calibrator.train(ds_tar.val, ds_tar.val, ds_tar.test)
    ## test the model
    calibrator.test(ds_tar.test, ld_name=args.tar, verbose=True)
    

    
def parse_args():
    ## inint a parser
    parser = argparse.ArgumentParser(description='digit dataset training')

    ## meta args
    parser.add_argument('--exp_name', required=True, type=str, help='experiment name')
    parser.add_argument('--snapshot_root', default='snapshots', type=str, help='snapshot root name')
    parser.add_argument('--cpu', action='store_true', help='use CPU')
    parser.add_argument('--cheatkey', action='store_true', help='enable cheatkey')

    ## dataset args
    parser.add_argument('--batch_size', default=100, type=int, help='batch size')
    parser.add_argument('--n_labels', default=10, type=int, help='the number of labels')
    parser.add_argument('--src', type=str, nargs='*', help='list of sources') ##TODO: how to restrict possible inputs?
    parser.add_argument('--tar', type=str, help='target') ##TODO: how to restrict possible inputs?
    parser.add_argument('--aug', type=str, nargs='*', default=[''], help='list of data augmentation') ##TODO: how to restrict possible inputs?
    parser.add_argument('--img_size', type=int, nargs=3, default=(28, 28, 1), help='image size')
    parser.add_argument('--sample_ratio', type=float, nargs=2, default=[1.0, 1.0])
    
    ## model args
    parser.add_argument('--model', default='ResNet18', type=str, help='model name')
    parser.add_argument('--model_adv', default='MidAdvFNN', type=str, help='adversarial network name')
    parser.add_argument('--iw', action='store_true', help='learn IW')
    parser.add_argument('--iw_type', type=str, default='srcdisc', help='IW model type')

    ## train args
    parser.add_argument('--train.find_best', action='store_true', help='find the best model')
    parser.add_argument('--train.load_final', action='store_true', help='load the final model')
    parser.add_argument('--train.optim', default='SGD', type=str, help='optimizer')
    parser.add_argument('--train.lr', default=0.1, type=float, help='learning rate')
    parser.add_argument('--train.lr_step_size', default=20, type=float, help='stepsize for step learning rate scheduler')
    parser.add_argument('--train.lr_step_decay_rate', default=0.5, type=float, help='decay rate for step learning rate scheduler')
    parser.add_argument('--train.weight_decay', type=float, default=0.0, help='L2 weight decay')
    parser.add_argument('--train.momentum', default=0.9, type=float, help='momentum')
    parser.add_argument('--train.n_epochs', default=100, type=int, help='the number of epochs')
    parser.add_argument('--train.val_period', default=1, type=int, help='validation period in epochs')
    parser.add_argument('--train.advtr_type', type=str, default='none', help='domain-adversarial training type')
    parser.add_argument('--train.reg_param_adv', type=float, default=1.0, help='adversarial loss regularization parameter')
    parser.add_argument('--train.schedule_reg_param_adv', action='store_true', help='schedule the adversarial loss regularization parameter')

    
    ## cal args
    parser.add_argument('--cal.find_best', action='store_true', help='find the best model')
    parser.add_argument('--cal.load_final', action='store_true', help='load the final model')
    parser.add_argument('--cal.optim', default='SGD', type=str, help='optimizer')
    parser.add_argument('--cal.lr', default=0.1, type=float, help='learning rate')
    parser.add_argument('--cal.lr_step_size', default=50, type=float, help='stepsize for step learning rate scheduler')
    parser.add_argument('--cal.lr_step_decay_rate', default=0.5, type=float, help='decay rate for step learning rate scheduler')
    parser.add_argument('--cal.momentum', default=0.9, type=float, help='momentum')
    parser.add_argument('--cal.n_epochs', default=500, type=int, help='the number of epochs')
    parser.add_argument('--cal.val_period', default=1, type=int, help='validation period in epochs')

    ## iw train args
    parser.add_argument('--train_iw.find_best', action='store_true', help='find the best model')
    parser.add_argument('--train_iw.load_final', action='store_true', help='load the final model')    
    parser.add_argument('--train_iw.optim', default='SGD', type=str, help='optimizer')
    parser.add_argument('--train_iw.lr', default=0.1, type=float, help='learning rate')
    parser.add_argument('--train_iw.lr_step_size', default=20, type=float, help='stepsize for step learning rate scheduler')
    parser.add_argument('--train_iw.lr_step_decay_rate', default=0.5, type=float, help='decay rate for step learning rate scheduler')
    parser.add_argument('--train_iw.weight_decay', type=float, default=0.0, help='L2 weight decay')
    parser.add_argument('--train_iw.momentum', default=0.9, type=float, help='momentum')
    parser.add_argument('--train_iw.n_epochs', default=100, type=int, help='the number of epochs')
    parser.add_argument('--train_iw.val_period', default=1, type=int, help='validation period in epochs')

    ## cal args
    parser.add_argument('--cal_iw.find_best', action='store_true', help='find the best model')
    parser.add_argument('--cal_iw.load_final', action='store_true', help='load the final model')    
    parser.add_argument('--cal_iw.optim', default='SGD', type=str, help='optimizer')
    parser.add_argument('--cal_iw.lr', default=0.1, type=float, help='learning rate')
    parser.add_argument('--cal_iw.lr_step_size', default=50, type=float, help='stepsize for step learning rate scheduler')
    parser.add_argument('--cal_iw.lr_step_decay_rate', default=0.5, type=float, help='decay rate for step learning rate scheduler')
    parser.add_argument('--cal_iw.momentum', default=0.9, type=float, help='momentum')
    parser.add_argument('--cal_iw.n_epochs', default=500, type=int, help='the number of epochs')
    parser.add_argument('--cal_iw.val_period', default=1, type=int, help='validation period in epochs')

    args = parser.parse_args()
    args = to_tree_namespace(args)

    ## init save_root
    args.train.save_root = os.path.join(args.snapshot_root, args.exp_name + '_%s'%(args.model))
    args.cal.save_root = args.train.save_root
    args.train_iw.save_root = args.train.save_root
    args.cal_iw.save_root = args.train.save_root

    # args.train.load_best = not args.train.find_best
    # args.cal.load_best = not args.cal.find_best
    # args.train_iw.load_best = not args.train_iw.find_best
    # args.cal_iw.load_best = not args.cal_iw.find_best
    
    
    ## init aug parameters
    args.aug_params = []
    for a in args.aug:
        if a == 'jitter':
            args.aug_params.append([('jitter', {'brightness': 0.4, 'contrast': 0.4, 'saturation': 0.4})])
            
        elif a == 'shake':
            args.aug_params.append([('randaug', {'size': 32, 'mode': 'SHAKE'})])
            
        elif a == 'svhnspec':
            args.aug_params.append([ 
                ('intensity_flip', {}),
                ('intensity_scaling', {'min': -1.5, 'max': 1.5}),
                ('intensity_offset', {'min': -0.5, 'max': 0.5}),
                ('affine', {'std': 0.1}),
                ('translation', {'x_max': 2.0, 'y_max': 2.0}),
                ('gaussian', {'std': 0.1}),
            ])
        else:
            ##TODO: simplify
            args.aug_params.append(None)
        
    return args


if __name__ == '__main__':
    args = parse_args()

    ##TODO:
    #strategy = tf.distribute.MirroredStrategy()
    #with strategy.scope():
    main(args)



