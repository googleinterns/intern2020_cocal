CUDA_VISIBLE_DEVICES=0 python3 main_rt.py --exp_name rt_advtrinit --train.find_best --train_advtr.load_final --data.aug svhnspec --train_base.find_best 
