mkdir -p snapshots/3srcs2s_aug_jitter
CUDA_VISIBLE_DEVICES=4 python3 main.py --exp_name 3srcs2s_aug_jitter --src MNIST USPS SynDigit --tar SVHN --aug svhnspec jitter > snapshots/3srcs2s_aug_jitter/out
