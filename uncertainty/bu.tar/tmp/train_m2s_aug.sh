mkdir -p snapshots/m2s_aug
CUDA_VISIBLE_DEVICES=3 python3 main.py --exp_name m2s_aug --src MNIST --tar SVHN --aug svhnspec > snapshots/m2s_aug/out
