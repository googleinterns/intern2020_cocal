CUDA_VISIBLE_DEVICES=7 python3 main_advtr.py --exp_name m2m_advtr_mid_0 --src MNIST --tar MNIST --train.advtr_type DANN --train.find_best --cheatkey --sample_ratio 0.5 0.5
CUDA_VISIBLE_DEVICES=7 python3 main_advtr.py --exp_name m2m_advtr_mid_1 --src MNIST --tar MNIST --train.advtr_type DANN --train.find_best --cheatkey --sample_ratio 0.5 0.5
CUDA_VISIBLE_DEVICES=7 python3 main_advtr.py --exp_name m2m_advtr_mid_2 --src MNIST --tar MNIST --train.advtr_type DANN --train.find_best --cheatkey --sample_ratio 0.5 0.5
CUDA_VISIBLE_DEVICES=7 python3 main_advtr.py --exp_name m2m_advtr_mid_3 --src MNIST --tar MNIST --train.advtr_type DANN --train.find_best --cheatkey --sample_ratio 0.5 0.5
CUDA_VISIBLE_DEVICES=7 python3 main_advtr.py --exp_name m2m_advtr_mid_4 --src MNIST --tar MNIST --train.advtr_type DANN --train.find_best --cheatkey --sample_ratio 0.5 0.5
CUDA_VISIBLE_DEVICES=7 python3 main_advtr.py --exp_name m2m_advtr_mid_5 --src MNIST --tar MNIST --train.advtr_type DANN --train.find_best --cheatkey --sample_ratio 0.5 0.5
CUDA_VISIBLE_DEVICES=7 python3 main_advtr.py --exp_name m2m_advtr_mid_6 --src MNIST --tar MNIST --train.advtr_type DANN --train.find_best --cheatkey --sample_ratio 0.5 0.5
CUDA_VISIBLE_DEVICES=7 python3 main_advtr.py --exp_name m2m_advtr_mid_7 --src MNIST --tar MNIST --train.advtr_type DANN --train.find_best --cheatkey --sample_ratio 0.5 0.5
CUDA_VISIBLE_DEVICES=7 python3 main_advtr.py --exp_name m2m_advtr_mid_8 --src MNIST --tar MNIST --train.advtr_type DANN --train.find_best --cheatkey --sample_ratio 0.5 0.5
CUDA_VISIBLE_DEVICES=7 python3 main_advtr.py --exp_name m2m_advtr_mid_9 --src MNIST --tar MNIST --train.advtr_type DANN --train.find_best --cheatkey --sample_ratio 0.5 0.5

