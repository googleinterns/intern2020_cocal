import os, sys
import argparse

import tensorflow as tf

import data
import model 
from util import *
from learning import LearnerCls
from learning import TempScalingCls as CalibratorCls
from learning import LearnerConfPred

##TODO: clean-up tf options
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

#gpus = tf.config.experimental.list_physical_devices('GPU')
#tf.config.experimental.set_memory_growth(gpus[0], True)


def main(args):

    ## init a snapshot path
    os.makedirs(args.train.save_root, exist_ok=True)

    ## init logger
    sys.stdout = Logger(os.path.join(args.train.save_root, 'out'))

    ## print args
    print_args(args)

    ## init gpus
    if not args.cpu:
        print("##GPUs Available: ", len(tf.config.experimental.list_physical_devices('GPU')))
        print()

    ## init datasets
    print("## init datasets")
    import numpy as np
    rot_deg = np.array(args.rot_deg).astype(np.float32)
    
    mu_pos = np.array([+0.6, +0.6]).astype(np.float32)
    mu_neg = np.array([-0.6, -0.6]).astype(np.float32)
    
    cov_pos = np.diag([0.01, 0.1]).astype(np.float32)
    cov_neg = np.diag([0.01, 0.1]).astype(np.float32)
    
    mu_pos_rot, cov_pos_rot = data.rot_gaussian(rot_deg, mu_pos, cov_pos)
    mu_neg_rot, cov_neg_rot = data.rot_gaussian(rot_deg, mu_neg, cov_neg)
    
    ds_src = data.TwoGaussians(
        100, 
        n_pos=10000, n_neg=10000,
        mu_pos=mu_pos, cov_pos=cov_pos,
        mu_neg=mu_neg, cov_neg=cov_neg
    )

    ds_tar = data.TwoGaussians(
        100, 
        n_pos=10000, n_neg=10000,
        mu_pos=mu_pos_rot, cov_pos=cov_pos_rot,
        mu_neg=mu_neg_rot, cov_neg=cov_neg_rot,
        seed=1,
    )

    #ds_joint = data.DomainDataset(args.src, args.aug_params, args.tar, batch_size=args.batch_size, val_shuffle=True, val_aug=True, test_aug=True) if args.iw else None
    print()
    

    ####
    ## base model learning
    ####
    print('## base model learning')
    ## init a base model
    mdl = getattr(model, args.model)(n_labels=args.n_labels, input_shape=(2,)) ##TODO: generalize
    ## init a learner
    learner = LearnerCls(args.train, mdl)
    ## train the model
    learner.train(ds_src.train, ds_src.val, ds_tar.test)
    ## test the model
    learner.test(ds_tar.test, ld_name=args.tar, verbose=True)
    learner.test(ds_src.test, ld_name='src', verbose=True)
    print()


    ####
    ## IW learning
    ####
    print('## IW model learning')
    import tensorflow_probability as tfp
    from model import IW_MoG
    p_pos = tfp.distributions.MultivariateNormalTriL(loc=mu_pos, scale_tril=tf.linalg.cholesky(cov_pos))
    p_neg = tfp.distributions.MultivariateNormalTriL(loc=mu_neg, scale_tril=tf.linalg.cholesky(cov_neg))
    p = tfp.distributions.Mixture(
        cat=tfp.distributions.Categorical(probs=[0.5, 0.5]),
        components=[p_pos, p_neg])

    q_pos = tfp.distributions.MultivariateNormalTriL(loc=mu_pos_rot, scale_tril=tf.linalg.cholesky(cov_pos_rot))
    q_neg = tfp.distributions.MultivariateNormalTriL(loc=mu_neg_rot, scale_tril=tf.linalg.cholesky(cov_neg_rot))
    q = tfp.distributions.Mixture(
        cat=tfp.distributions.Categorical(probs=[0.5, 0.5]),
        components=[q_pos, q_neg])

    mdl_iw = IW_MoG(p, q)
    print()

    
    ####
    ## conf learning
    ####
    print('## conf learning')
    ## init a base model
    if args.conf.model == 'c+w':
        mdl_conf = model.ConfPred(mdl, mdl_iw)
    elif args.conf.model == 'c':
        mdl_conf = model.NaiveConfPred(mdl)
    else:
        raise NotImplementedError
    mdl_iw_cond = IW_MoG(p, q, model_conf=mdl_conf)
    ## init a learner
    learner = LearnerConfPred(args.conf, mdl_conf, mdl, mdl_iw_cond)
    ## train the model
    learner.train(ds_src.val, ds_src.val, ds_tar.test)
    ## test the model
    learner.test(ds_tar.test, ld_name='tar', verbose=True)
    learner.test(ds_src.test, ld_name='src', verbose=True)
    print()
    

    
def parse_args():
    ## inint a parser
    parser = argparse.ArgumentParser(description='digit dataset training')

    ## meta args
    parser.add_argument('--exp_name', required=True, type=str, help='experiment name')
    parser.add_argument('--snapshot_root', default='snapshots', type=str, help='snapshot root name')
    parser.add_argument('--cpu', action='store_true', help='use CPU')

    ## dataset args
    parser.add_argument('--batch_size', default=100, type=int, help='batch size')
    parser.add_argument('--n_labels', default=10, type=int, help='the number of labels')
    parser.add_argument('--src', type=str, nargs='*', help='list of sources') ##TODO: how to restrict possible inputs?
    parser.add_argument('--tar', type=str, help='target') ##TODO: how to restrict possible inputs?
    parser.add_argument('--aug', type=str, nargs='*', default=[''], help='list of data augmentation') ##TODO: how to restrict possible inputs?

    parser.add_argument('--rot_deg', type=float, default=60.0, help='dataset shift rotation degree')
    
    
    ## model args
    parser.add_argument('--model', default='ResNet18',  type=str, help='model name')
    parser.add_argument('--iw', action='store_true', help='learn IW')
    parser.add_argument('--iw_type', type=str, default='srcdisc', help='IW model type')

    ## train args
    #parser.add_argument('--train.load_best', action='store_true', help='load the best model')
    parser.add_argument('--train.find_best', action='store_true', help='find the best model')
    parser.add_argument('--train.optim', default='SGD', type=str, help='optimizer')
    parser.add_argument('--train.lr', default=0.1, type=float, help='learning rate')
    parser.add_argument('--train.lr_step_size', default=100, type=float, help='stepsize for step learning rate scheduler')
    parser.add_argument('--train.lr_step_decay_rate', default=0.5, type=float, help='decay rate for step learning rate scheduler')
    parser.add_argument('--train.momentum', default=0.9, type=float, help='momentum')
    parser.add_argument('--train.n_epochs', default=500, type=int, help='the number of epochs')
    parser.add_argument('--train.val_period', default=1, type=int, help='validation period in epochs')

    ## cal args
    #parser.add_argument('--cal.load_best', action='store_true', help='load the best model')
    parser.add_argument('--cal.find_best', action='store_true', help='find the best model')
    parser.add_argument('--cal.optim', default='SGD', type=str, help='optimizer')
    parser.add_argument('--cal.lr', default=0.1, type=float, help='learning rate')
    parser.add_argument('--cal.lr_step_size', default=50, type=float, help='stepsize for step learning rate scheduler')
    parser.add_argument('--cal.lr_step_decay_rate', default=0.5, type=float, help='decay rate for step learning rate scheduler')
    parser.add_argument('--cal.momentum', default=0.9, type=float, help='momentum')
    parser.add_argument('--cal.n_epochs', default=500, type=int, help='the number of epochs')
    parser.add_argument('--cal.val_period', default=1, type=int, help='validation period in epochs')

    ## conf args
    parser.add_argument('--conf.find_best', action='store_true', help='find the best model')
    parser.add_argument('--conf.model', type=str, default='c+w', help='model name')
    parser.add_argument('--conf.eps', type=float, default=0.05, help='epsilon')
    parser.add_argument('--conf.T_max', type=float, default=1.0, help='T max range')
    parser.add_argument('--conf.T_min', type=float, default=1e-6, help='T min range')
    parser.add_argument('--conf.T_step', type=float, default=0.01, help='T step size')
    

    ## iw train args
    #parser.add_argument('--train_iw.load_best', action='store_true', help='load the best model')
    parser.add_argument('--train_iw.find_best', action='store_true', help='find the best model')
    parser.add_argument('--train_iw.optim', default='SGD', type=str, help='optimizer')
    parser.add_argument('--train_iw.lr', default=0.1, type=float, help='learning rate')
    parser.add_argument('--train_iw.lr_step_size', default=20, type=float, help='stepsize for step learning rate scheduler')
    parser.add_argument('--train_iw.lr_step_decay_rate', default=0.5, type=float, help='decay rate for step learning rate scheduler')
    parser.add_argument('--train_iw.momentum', default=0.9, type=float, help='momentum')
    parser.add_argument('--train_iw.n_epochs', default=100, type=int, help='the number of epochs')
    parser.add_argument('--train_iw.val_period', default=1, type=int, help='validation period in epochs')

    ## cal args
    #parser.add_argument('--cal_iw.load_best', action='store_true', help='load the best model')
    parser.add_argument('--cal_iw.find_best', action='store_true', help='find the best model')
    parser.add_argument('--cal_iw.optim', default='SGD', type=str, help='optimizer')
    parser.add_argument('--cal_iw.lr', default=0.1, type=float, help='learning rate')
    parser.add_argument('--cal_iw.lr_step_size', default=50, type=float, help='stepsize for step learning rate scheduler')
    parser.add_argument('--cal_iw.lr_step_decay_rate', default=0.5, type=float, help='decay rate for step learning rate scheduler')
    parser.add_argument('--cal_iw.momentum', default=0.9, type=float, help='momentum')
    parser.add_argument('--cal_iw.n_epochs', default=500, type=int, help='the number of epochs')
    parser.add_argument('--cal_iw.val_period', default=1, type=int, help='validation period in epochs')

    args = parser.parse_args()
    args = to_tree_namespace(args)

    ## init save_root
    args.train.save_root = os.path.join(args.snapshot_root, args.exp_name + '_%s'%(args.model))
    args.cal.save_root = args.train.save_root
    args.conf.save_root = args.train.save_root
    args.train_iw.save_root = args.train.save_root
    args.cal_iw.save_root = args.train.save_root

    args.train.load_best = not args.train.find_best
    args.cal.load_best = not args.cal.find_best
    args.conf.load_best = not args.conf.find_best
    args.train_iw.load_best = not args.train_iw.find_best
    args.cal_iw.load_best = not args.cal_iw.find_best
    
    
    ## init aug parameters
    args.aug_params = []
    for a in args.aug:
        if a == 'jitter':
            args.aug_params.append([('jitter', {'brightness': 0.4, 'contrast': 0.4, 'saturation': 0.4})])
            
        elif a == 'shake':
            args.aug_params.append([('randaug', {'size': 32, 'mode': 'SHAKE'})])
            
        elif a == 'svhnspec':
            args.aug_params.append([ 
                ('intensity_flip', {}),
                ('intensity_scaling', {'min': -1.5, 'max': 1.5}),
                ('intensity_offset', {'min': -0.5, 'max': 0.5}),
                ('affine', {'std': 0.1}),
                ('translation', {'x_max': 2.0, 'y_max': 2.0}),
                ('gaussian', {'std': 0.1}),
            ])
        else:
            ##TODO: simplify
            args.aug_params.append(None)
        
    return args


if __name__ == '__main__':
    args = parse_args()

    ##TODO:
    #strategy = tf.distribute.MirroredStrategy()
    #with strategy.scope():
    main(args)



