ROOT="snapshots/to_svhn_aug_ResNet18"
mkdir -p $ROOT
CUDA_VISIBLE_DEVICES=7 python3 main.py --exp_name to_svhn_aug --src MNIST USPS SynDigit --aug jitter shake --tar SVHN > $ROOT/out
