CUDA_VISIBLE_DEVICES=5 python3 main_self.py --exp_name m2m_self_small_ideal_0 --data.src MNIST --data.tar MNIST --train.find_best --data.sample_ratio 0.1 0.1 --train_base.find_best --ideal
CUDA_VISIBLE_DEVICES=5 python3 main_self.py --exp_name m2m_self_small_ideal_1 --data.src MNIST --data.tar MNIST --train.find_best --data.sample_ratio 0.1 0.1 --train_base.find_best --ideal
CUDA_VISIBLE_DEVICES=5 python3 main_self.py --exp_name m2m_self_small_ideal_2 --data.src MNIST --data.tar MNIST --train.find_best --data.sample_ratio 0.1 0.1 --train_base.find_best --ideal
CUDA_VISIBLE_DEVICES=5 python3 main_self.py --exp_name m2m_self_small_ideal_3 --data.src MNIST --data.tar MNIST --train.find_best --data.sample_ratio 0.1 0.1 --train_base.find_best --ideal
CUDA_VISIBLE_DEVICES=5 python3 main_self.py --exp_name m2m_self_small_ideal_4 --data.src MNIST --data.tar MNIST --train.find_best --data.sample_ratio 0.1 0.1 --train_base.find_best --ideal
CUDA_VISIBLE_DEVICES=5 python3 main_self.py --exp_name m2m_self_small_ideal_5 --data.src MNIST --data.tar MNIST --train.find_best --data.sample_ratio 0.1 0.1 --train_base.find_best --ideal
CUDA_VISIBLE_DEVICES=5 python3 main_self.py --exp_name m2m_self_small_ideal_6 --data.src MNIST --data.tar MNIST --train.find_best --data.sample_ratio 0.1 0.1 --train_base.find_best --ideal
CUDA_VISIBLE_DEVICES=5 python3 main_self.py --exp_name m2m_self_small_ideal_7 --data.src MNIST --data.tar MNIST --train.find_best --data.sample_ratio 0.1 0.1 --train_base.find_best --ideal
CUDA_VISIBLE_DEVICES=5 python3 main_self.py --exp_name m2m_self_small_ideal_8 --data.src MNIST --data.tar MNIST --train.find_best --data.sample_ratio 0.1 0.1 --train_base.find_best --ideal
CUDA_VISIBLE_DEVICES=5 python3 main_self.py --exp_name m2m_self_small_ideal_9 --data.src MNIST --data.tar MNIST --train.find_best --data.sample_ratio 0.1 0.1 --train_base.find_best --ideal


