import os, sys
import numpy as np

import tensorflow as tf

import model
from model.util import *


class TargetPseudoLabeling:
    def __init__(self, model_base, model_conf, ld_tar, ideal=False):
        self.model_base = model_base
        self.model_conf = model_conf
        self.ld_tar = ld_tar
        self.ideal = ideal
        

    def __iter__(self):
        self.iter = iter(self.ld_tar)
        return self

    
    def __next__(self):
        def sample_from_target():
            while True:
                x, y = next(self.iter)
                if len(x.shape) == 5:
                    x_tc, x_st = x[:, 0, :, :, :], x[:, 1, :, :, :]
                else:
                    x_tc, x_st = x, x
                y_pred = self.model_base(x_tc)['y_pred']
                conf = self.model_conf(x_tc) ##TODO: return dict?
                
                if self.ideal:
                    x_conf_i, y_conf_i, y_true_i = x_st[conf==1], y[conf==1], y[conf==1]
                else:
                    x_conf_i, y_conf_i, y_true_i = x_st[conf==1], y_pred[conf==1], y[conf==1]

                if any(conf==1):
                    break
                        
            ##TODO: can small examples make some problems?

            # print("#conf =", x_conf_i.shape[0],
            #       "precision =", tf.math.reduce_mean(tf.cast(tf.cast(y_conf_i, tf.int64) == tf.cast(y_true_i, tf.int64), tf.float32)).numpy())
            return x_conf_i, y_conf_i

        return sample_from_target()

    
class PseudoLabeling:
    def __init__(self, model_base, model_conf, ld_src, ld_tar, ideal=False):
        self.model_base = model_base
        self.model_conf = model_conf
        self.ld_src = ld_src
        self.ld_tar = ld_tar
        self.ideal = ideal
        

    def __iter__(self):
        self.iter_end = {'src': False, 'tar': False}
        self.iter = {'src': iter(self.ld_src), 'tar': iter(self.ld_tar)}
        return self

    
    def __next__(self):

        ## source
        def sample_from_source():
            return next(self.iter['src'])

        try:
            x, y = sample_from_source()
        except StopIteration:
            self.iter_end['src'] = True

            if self.iter_end['src'] and self.iter_end['tar']:
                raise StopIteration
            else:
                self.iter['src'] = iter(self.ld_src)
                x, y = sample_from_source()
        x_src, y_src = x, y

        ## target
        def sample_from_target():
            while True:
                x, y = next(self.iter['tar'])
                if len(x.shape) == 5:
                    x_tc, x_st = x[:, 0, :, :, :], x[:, 1, :, :, :] # two different augmentation
                else:
                    x_tc, x_st = x, x

                y_pred = self.model_base(x_tc)['y_pred']
                conf = self.model_conf(x_tc) ##TODO: return dict?
                
                if self.ideal:
                    x_conf_i, y_conf_i, y_true_i = x_st[conf==1], y[conf==1], y[conf==1]
                else:
                    x_conf_i, y_conf_i, y_true_i = x_st[conf==1], y_pred[conf==1], y[conf==1]

                if any(conf==1):
                    break


            # ##TODO: clean-way to upsample?
            # n_repeat = x_st.shape[0] // x_conf_i.shape[0]
            # x_conf = tf.repeat(x_conf_i, n_repeat, 0)
            # y_conf = tf.repeat(y_conf_i, n_repeat, 0)
            # y_true = tf.repeat(y_true_i, n_repeat, 0)
            
            # n_remain = x_st.shape[0] - x_conf.shape[0]
            # if n_remain > 0:
            #     x_conf = tf.concat((x_conf, x_conf_i[:n_remain]), 0)
            #     y_conf = tf.concat((y_conf, y_conf_i[:n_remain]), 0)
            #     y_true = tf.concat((y_true, y_true_i[:n_remain]), 0)
                

            x_conf, y_conf = x_conf_i, y_conf_i
            
            
            # print("#conf =", x_conf.shape[0],
            #       "precision =", tf.math.reduce_mean(tf.cast(tf.cast(y_conf, tf.int64) == tf.cast(y_true, tf.int64), tf.float32)).numpy())

            return x_conf, y_conf

        try:
            x, y = sample_from_target()
        except StopIteration:
            self.iter_end['tar'] = True

            if self.iter_end['src'] and self.iter_end['tar']:
                raise StopIteration
            else:
                self.iter['tar'] = iter(self.ld_tar)

                try:
                    x, y = sample_from_target()
                except StopIteration:
                    # it is possible that there are no confident examples
                    x, y = None, None
                    
        x_tar, y_tar = x, y
        
        
        # ## merge
        # if x_tar is not None:
        #     x = tf.concat((x_src, x_tar), 0)
        #     y = tf.concat((tf.cast(y_src, tf.int64), tf.cast(y_tar, tf.int64)), 0)
        # else:
        #     x, y = x_src, y_src
        # return x, y

        return (x_src, x_tar), (tf.cast(y_src, tf.int64), tf.cast(y_tar, tf.int64))
                    

class Teacher(tf.keras.Model):
    def __init__(self, params, model_base, ds_src, ds_tar, ideal=False):
        super().__init__()

        self.model_base = model_base
        self.ideal = ideal
        self.model_conf = getattr(model, params.conf)(self.model_base)
        
        # if not hasattr(params, 'iw') or params.iw == 'none':
        #     self.model_conf = getattr(model, params.conf)(self.model_base)
        # else:
        #     model_sd_head = getattr(model, params.iw)(self.model_base.dim_feat, 2, 50*params.n_labels)
        #     model_sd = model.SourceDisc(self.model_base.model, model_sd_head)
        #     model_sd_cal = model.TempCls(model_sd)
        #     model_iw = model.IW(model_sd_cal)
        #     self.model_conf = getattr(model, params.conf)(self.model_base, model_iw)
            
        self.train = PseudoLabeling(self.model_base, self.model_conf, ds_src.train, ds_tar.train, ideal)
        self.val = TargetPseudoLabeling(self.model_base, self.model_conf, ds_tar.val, ideal) ##TODO: target only
        self.test = TargetPseudoLabeling(self.model_base, self.model_conf, ds_tar.test, ideal) ##TODO: target only
        

class Student(Teacher):
    def __init__(self, params, model_base, ds_src, ds_tar, ideal=False):
        super().__init__(params, model_base, ds_src, ds_tar, ideal)
