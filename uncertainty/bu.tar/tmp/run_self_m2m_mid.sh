CUDA_VISIBLE_DEVICES=1 python3 main_self.py --exp_name m2m_self_mid_0 --data.src MNIST --data.tar MNIST --train.find_best --data.sample_ratio 0.5 0.5 --train_base.find_best
CUDA_VISIBLE_DEVICES=1 python3 main_self.py --exp_name m2m_self_mid_1 --data.src MNIST --data.tar MNIST --train.find_best --data.sample_ratio 0.5 0.5 --train_base.find_best
CUDA_VISIBLE_DEVICES=1 python3 main_self.py --exp_name m2m_self_mid_2 --data.src MNIST --data.tar MNIST --train.find_best --data.sample_ratio 0.5 0.5 --train_base.find_best
CUDA_VISIBLE_DEVICES=1 python3 main_self.py --exp_name m2m_self_mid_3 --data.src MNIST --data.tar MNIST --train.find_best --data.sample_ratio 0.5 0.5 --train_base.find_best
CUDA_VISIBLE_DEVICES=1 python3 main_self.py --exp_name m2m_self_mid_4 --data.src MNIST --data.tar MNIST --train.find_best --data.sample_ratio 0.5 0.5 --train_base.find_best
CUDA_VISIBLE_DEVICES=1 python3 main_self.py --exp_name m2m_self_mid_5 --data.src MNIST --data.tar MNIST --train.find_best --data.sample_ratio 0.5 0.5 --train_base.find_best
CUDA_VISIBLE_DEVICES=1 python3 main_self.py --exp_name m2m_self_mid_6 --data.src MNIST --data.tar MNIST --train.find_best --data.sample_ratio 0.5 0.5 --train_base.find_best
CUDA_VISIBLE_DEVICES=1 python3 main_self.py --exp_name m2m_self_mid_7 --data.src MNIST --data.tar MNIST --train.find_best --data.sample_ratio 0.5 0.5 --train_base.find_best
CUDA_VISIBLE_DEVICES=1 python3 main_self.py --exp_name m2m_self_mid_8 --data.src MNIST --data.tar MNIST --train.find_best --data.sample_ratio 0.5 0.5 --train_base.find_best
CUDA_VISIBLE_DEVICES=1 python3 main_self.py --exp_name m2m_self_mid_9 --data.src MNIST --data.tar MNIST --train.find_best --data.sample_ratio 0.5 0.5 --train_base.find_best


