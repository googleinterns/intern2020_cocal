import os, sys
import numpy as np
import argparse

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

import tensorflow as tf

import data
import model 
from uncertainty import ECE


if __name__ == '__main__':

    parser = argparse.ArgumentParser(description='plot ECE trend')

    ## meta args
    parser.add_argument('--src', type=str, nargs='*', help='list of sources') ##TODO: how to restrict possible inputs?
    parser.add_argument('--aug', action='store_true')
    parser.add_argument('--fontsize', type=int, default=15)
    

    args = parser.parse_args()

    fontsize = args.fontsize
    aug = args.aug

    if aug:
        T_rng = np.arange(0.1, 10.0+0.1, 0.1)
        aug_params = [[ 
                ('intensity_flip', {}),
                ('intensity_scaling', {'min': -1.5, 'max': 1.5}),
                ('intensity_offset', {'min': -0.5, 'max': 0.5}),
                ('affine', {'std': 0.1}),
                ('translation', {'x_max': 2.0, 'y_max': 2.0}),
                ('gaussian', {'std': 0.1}),
            ]]
    else:
        T_rng = np.concatenate((np.array(1), np.arange(10.0, 500.0+10.0, 10.0)))
        aug_params = [None]
    print(T_rng)

    
    ## init a loader
    ds_src_m = data.MultiSourceDataset(, aug_params, batch_size=100, val_shuffle=True, val_aug=True)
    ds_src_mus = data.MultiSourceDataset(['MNIST', 'USPS', 'SynDigit'], aug_params, batch_size=100, val_shuffle=True, val_aug=True)

    ds_tar = getattr(data, 'SVHN')(batch_size=100, val_shuffle=True)

    ## load a trained model
    mdl = getattr(model, 'ResNet18')(num_class=10, activation='relu', input_shape=(32, 32, 3)) ##TODO: generalize
    mdl_cal_m = model.TempCls(mdl)
    mdl_cal_m.load_weights('snapshots/m2svhn%s_ResNet18/model_params_cal_best'%('_aug' if aug else ''))

    ## load a trained model
    mdl = getattr(model, 'ResNet18')(num_class=10, activation='relu', input_shape=(32, 32, 3)) ##TODO: generalize
    mdl_cal_mus = model.TempCls(mdl)
    mdl_cal_mus.load_weights('snapshots/mus2svhn%s_ResNet18/model_params_cal_best'%('_aug' if aug else ''))

    ## error/ece
    Ts, eces_m, eces_mus, eces_m_src, eces_mus_src = [], [], [], [], []
    for T in np.arange(0.1, 10.0, 0.1):
        mdl_cal_m.T = tf.constant(T, dtype=tf.float32)
        mdl_cal_mus.T = tf.constant(T, dtype=tf.float32)

        ## target
        ph_list_m, yh_list_m, y_list_m = [], [], []
        ph_list_mus, yh_list_mus, y_list_mus = [], [], []

        for x, y in ds_tar.test:
            ## mnist model
            logits = mdl_cal_m(x, training=False)['logits']
            ph = tf.math.reduce_max(tf.nn.softmax(logits, -1), -1)
            yh = tf.math.argmax(logits, -1)
            ph_list_m.append(ph.numpy())
            yh_list_m.append(yh.numpy())
            y_list_m.append(y.numpy())
            
            ## mus model
            logits = mdl_cal_mus(x, training=False)['logits']
            ph = tf.math.reduce_max(tf.nn.softmax(logits, -1), -1)
            yh = tf.math.argmax(logits, -1)
            ph_list_mus.append(ph.numpy())
            yh_list_mus.append(yh.numpy())
            y_list_mus.append(y.numpy())
            
        ece_m = ECE(np.concatenate(ph_list_m), np.concatenate(yh_list_m), np.concatenate(y_list_m), rel_diag_fn=os.path.join('plots', 'rel_diag_m%s_T_%f'%('_aug' if aug else '', T)))
        ece_mus = ECE(np.concatenate(ph_list_mus), np.concatenate(yh_list_mus), np.concatenate(y_list_mus), rel_diag_fn=os.path.join('plots', 'rel_diag_mus%s_T_%f'%('_aug' if aug else '', T)))

        print("T = %f, error_m = %f, error_mus = %f ECE_m = %.2f%% , ECE_mus = %.2f%%"%(
            T,
            np.mean(np.concatenate(y_list_m) != np.concatenate(yh_list_m)),
            np.mean(np.concatenate(y_list_mus) != np.concatenate(yh_list_mus)),
            ece_m*100.0, ece_mus*100.0))
        Ts.append(T)
        eces_m.append(ece_m*100.0)
        eces_mus.append(ece_mus*100.0)

        ## draw the best reliability diagram
        if T == Ts[np.argmin(np.array(eces_m))]:
            ECE(np.concatenate(ph_list_m), np.concatenate(yh_list_m), np.concatenate(y_list_m), rel_diag_fn=os.path.join('plots', 'rel_diag_m%s_best_T'%('_aug' if aug else '')))
        if T == Ts[np.argmin(np.array(eces_mus))]:
            ECE(np.concatenate(ph_list_mus), np.concatenate(yh_list_mus), np.concatenate(y_list_mus), rel_diag_fn=os.path.join('plots', 'rel_diag_mus%s_best_T'%('_aug' if aug else '')))


        ## plot
        plt.figure(1)
        plt.clf()

        h1 = plt.plot(Ts, eces_m, 'r-', label='M to SVHN')
        h2 = plt.plot(Ts, eces_mus, 'b-', label='M+U+S to SVHN')

        h3 = plt.plot(Ts[np.argmin(np.array(eces_m))], min(eces_m), 'rs', label='M min')
        h4 = plt.plot(Ts[np.argmin(np.array(eces_mus))], min(eces_mus), 'bs', label='M+U+S min')

        plt.xlabel('temperature', fontsize=fontsize)
        plt.ylabel('ECE (%%)', fontsize=fontsize)
        plt.grid('on')
        plt.legend(handles=[h1[0], h2[0]], fontsize=fontsize)

        ## save
        plt.savefig('plots/plot_temp_trend_svhn%s.png'%('_aug' if aug else ''), bbox_inches='tight')
        plt.close()
    
    


