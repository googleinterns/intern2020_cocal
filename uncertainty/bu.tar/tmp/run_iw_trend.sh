screen -dm bash -c "PYTHONPATH=. CUDA_VISIBLE_DEVICES=1 python3 plots/plot_iw.py --src MNIST"
screen -dm bash -c "PYTHONPATH=. CUDA_VISIBLE_DEVICES=2 python3 plots/plot_iw.py --src MNIST USPS SynDigit"
screen -dm bash -c "PYTHONPATH=. CUDA_VISIBLE_DEVICES=3 python3 plots/plot_iw.py --src MNIST --aug"
screen -dm bash -c "PYTHONPATH=. CUDA_VISIBLE_DEVICES=4 python3 plots/plot_iw.py --src MNIST USPS SynDigit --aug"
