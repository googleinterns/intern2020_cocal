mkdir -p snapshots/3srcs2s_aug
CUDA_VISIBLE_DEVICES=6 python3 main.py --exp_name 3srcs2s_aug --src MNIST USPS SynDigit --tar SVHN --aug svhnspec > snapshots/3srcs2s_aug/out
