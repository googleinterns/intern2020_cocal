for i in {0..9}
do
    CUDA_VISIBLE_DEVICES=4 python3 main_advtr.py --exp_name m2u_srconly_comp_$i --data.src MNIST --data.tar USPS --data.aug svhnspec --train.find_best --train.advtr_type none
done
