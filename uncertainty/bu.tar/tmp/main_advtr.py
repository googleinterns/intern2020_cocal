import os, sys
import argparse
import itertools
import tensorflow as tf

import data
import model 
from util import *
from learning import LearnerCls, LearnerDACls
from learning import TempScalingCls as CalibratorCls

##TODO: clean-up tf options
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

#gpus = tf.config.experimental.list_physical_devices('GPU')
#tf.config.experimental.set_memory_growth(gpus[0], True)


def main(args):

    ## init a snapshot path
    os.makedirs(args.train.save_root, exist_ok=True)

    ## init logger
    sys.stdout = Logger(os.path.join(args.train.save_root, 'out'))

    ## print args
    print_args(args)

    ## init gpus
    if not args.cpu:
        print("##GPUs Available: ", len(tf.config.experimental.list_physical_devices('GPU')))
        print()

    ## init datasets
    print("## init datasets")
    ds_src = data.MultiSourceDataset(args.data.src, args.aug_params, batch_size=args.data.batch_size, val_shuffle=True, val_aug=True, domain_id=1,
                                     color=False if args.data.img_size[2]==1 else True, size=args.data.img_size[0], sample_ratio=args.data.sample_ratio[0])
    ds_tar = getattr(data, args.data.tar)(root=os.path.join('data', args.data.tar.lower()), batch_size=args.data.batch_size, val_shuffle=True, domain_id=0,
                                     color=False if args.data.img_size[2]==1 else True, size=args.data.img_size[0], sample_ratio=args.data.sample_ratio[1])
    if args.merge_train_val:
        ds_src.train = data.ChainLoader(ds_src.train, ds_src.val)
        ds_tar.train = data.ChainLoader(ds_tar.train, ds_tar.val)
    
    ds_dom = data.DomainDataset(ds_src, ds_tar)
    print()

    ####
    ## base model learning
    ####
    print('## base model learning')
    ## init a base model
    mdl = getattr(model, args.model)(num_class=args.data.n_labels, input_shape=args.data.img_size) ##TODO: generalize
    if args.train.advtr_type == 'none':
        ## init a learner
        learner = LearnerCls(args.train, mdl)
        ## train the model
        learner.train(ds_src.train, ds_src.val, ds_tar.test)
    else:
        ## init a adv model
        mdl_adv = getattr(model, args.model_adv)(n_in=mdl.dim_feat)
        ## init a learner
        learner = LearnerDACls(args.train, model.DAN(mdl, mdl_adv))
        ## train the model
        learner.train([ds_src.train, ds_dom.train], ds_tar.val if args.cheatkey else ds_src.val, ds_tar.test)
        
    ## test the model
    learner.test(ds_tar.test, ld_name=args.data.tar, verbose=True)
    #learner.test(ds_src.test, ld_name='src', verbose=True)
    print()


    

    
def parse_args():
    ## inint a parser
    parser = argparse.ArgumentParser(description='digit dataset training')

    ## meta args
    parser.add_argument('--exp_name', required=True, type=str, help='experiment name')
    parser.add_argument('--snapshot_root', default='snapshots', type=str, help='snapshot root name')
    parser.add_argument('--cpu', action='store_true', help='use CPU')
    parser.add_argument('--cheatkey', action='store_true', help='enable cheatkey')
    parser.add_argument('--merge_train_val', action='store_true', help='merge train and validataion set')

    ## dataset args
    parser.add_argument('--data.batch_size', default=100, type=int, help='batch size')
    parser.add_argument('--data.n_labels', default=10, type=int, help='the number of labels')
    parser.add_argument('--data.src', type=str, nargs='*', help='list of sources') ##TODO: how to restrict possible inputs?
    parser.add_argument('--data.tar', type=str, help='target') ##TODO: how to restrict possible inputs?
    parser.add_argument('--data.aug', type=str, nargs='*', default=[''], help='list of data augmentation') ##TODO: how to restrict possible inputs?
    parser.add_argument('--data.img_size', type=int, nargs=3, default=(32, 32, 3), help='image size')
    parser.add_argument('--data.sample_ratio', type=float, nargs=2, default=[1.0, 1.0])
    
    ## model args
    parser.add_argument('--model', default='ResNet18', type=str, help='model name')
    parser.add_argument('--model_adv', default='BigAdvFNN', type=str, help='adversarial network name')
    # parser.add_argument('--iw', action='store_true', help='learn IW')
    # parser.add_argument('--iw_type', type=str, default='srcdisc', help='IW model type')

    ## train args
    parser.add_argument('--train.find_best', action='store_true', help='find the best model')
    parser.add_argument('--train.load_final', action='store_true', help='load the final model')
    parser.add_argument('--train.optim', default='SGD', type=str, help='optimizer')
    parser.add_argument('--train.lr', default=0.01, type=float, help='learning rate')
    parser.add_argument('--train.lr_step_size', default=20, type=float, help='stepsize for step learning rate scheduler')
    parser.add_argument('--train.lr_step_decay_rate', default=0.5, type=float, help='decay rate for step learning rate scheduler')
    parser.add_argument('--train.weight_decay', type=float, default=0.0, help='L2 weight decay')
    parser.add_argument('--train.momentum', default=0.9, type=float, help='momentum')
    parser.add_argument('--train.n_epochs', default=100, type=int, help='the number of epochs')
    parser.add_argument('--train.val_period', default=1, type=int, help='validation period in epochs')
    parser.add_argument('--train.advtr_type', type=str, default='DANN', help='domain-adversarial training type')
    parser.add_argument('--train.reg_param_adv', type=float, default=1.0, help='adversarial loss regularization parameter')
    parser.add_argument('--train.no_adv_reg_schedule', action='store_true', help='do not schedule the adversarial loss regularization parameter')

    
    args = parser.parse_args()
    args = to_tree_namespace(args)

    ## init save_root
    args.train.save_root = os.path.join(args.snapshot_root, args.exp_name + '_%s'%(args.model))    

    args.train.schedule_reg_param_adv = not args.train.no_adv_reg_schedule
    ## init aug parameters
    args.aug_params = []
    for a in args.data.aug:
        if a == 'jitter':
            args.aug_params.append([('jitter', {'brightness': 0.4, 'contrast': 0.4, 'saturation': 0.4})])
            
        elif a == 'shake':
            args.aug_params.append([('randaug', {'size': 32, 'mode': 'SHAKE'})])
            
        elif a == 'svhnspec':
            args.aug_params.append([ 
                ('intensity_flip', {}),
                ('intensity_scaling', {'min': -1.5, 'max': 1.5}),
                ('intensity_offset', {'min': -0.5, 'max': 0.5}),
                ('affine', {'std': 0.1}),
                ('translation', {'x_max': 2.0, 'y_max': 2.0}),
                ('gaussian', {'std': 0.1}),
            ])
        else:
            ##TODO: simplify
            args.aug_params.append(None)
        
    return args


if __name__ == '__main__':
    args = parse_args()
    main(args)



