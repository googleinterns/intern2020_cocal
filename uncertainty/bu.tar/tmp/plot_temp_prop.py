import os
import numpy as np

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

os.environ['CUDA_VISIBLE_DEVICES'] = ''
#import tensorflow as tf
#import torch as tf

import torch as tc
import torch.nn.functional as F
softmax = lambda x: F.softmax(tc.tensor(x), -1)

fontsize = 15
fn = 'temp_order_prop'

ys = [0, 1, 2]

z1 = np.array([1.0, 1.1, 1.105])
z2 = np.array([1.0, 1.2, 1.21])

T1 = 1.0
T2 = 0.1

sm_x1_T1 = softmax(z1/T1)
sm_x2_T1 = softmax(z2/T1)

sm_x1_T2 = softmax(z1/T2)
sm_x2_T2 = softmax(z2/T2)


print(sm_x1_T1.numpy(), sm_x2_T1.numpy(), sm_x1_T1.numpy().max() > sm_x2_T1.numpy().max())
print(sm_x1_T2.numpy(), sm_x2_T2.numpy(), sm_x1_T2.numpy().max() > sm_x2_T2.numpy().max())


plt.figure(1)
plt.clf()

h1 = plt.bar(ys, sm_x1_T1, width=(ys[1]-ys[0])*0.75, color='b', edgecolor='k', alpha=1.0, label='x1')
h2 = plt.bar(ys, sm_x1_T1, width=(ys[1]-ys[0])*0.50, color='r', edgecolor='k', alpha=1.0, label='x2')

plt.grid('on')
#plt.ylim((0.0, 1.0))
plt.xlabel('y', fontsize=fontsize)
plt.ylabel('p(y | x)', fontsize=fontsize)
plt.legend(handles=[h1, h2], fontsize=fontsize)

## save
plt.savefig(fn+'.png', bbox_inches='tight')
    




