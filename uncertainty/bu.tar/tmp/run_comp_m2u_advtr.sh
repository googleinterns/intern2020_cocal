for i in {0..9}
do
    CUDA_VISIBLE_DEVICES=5 python3 main_advtr.py --exp_name m2u_advtr_comp_$i --data.src MNIST --data.tar USPS --data.aug svhnspec --train.find_best --train.advtr_type DANN --train.load_final --merge_train_val
done
