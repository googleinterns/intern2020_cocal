import os, sys
import argparse

import tensorflow as tf

import data
import model 
from util import *
from learning import LearnerCls
from learning import TempScalingCls as CalibratorCls

##TODO: clean-up tf options
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

#gpus = tf.config.experimental.list_physical_devices('GPU')
#tf.config.experimental.set_memory_growth(gpus[0], True)


def main(args):

    ## init a snapshot path
    os.makedirs(args.train.save_root, exist_ok=True)

    ## init logger
    sys.stdout = Logger(os.path.join(args.train.save_root, 'out'))

    ## print args
    print_args(args)

    ## init gpus
    if not args.cpu:
        print("##GPUs Available: ", len(tf.config.experimental.list_physical_devices('GPU')))
        print()

    ## init datasets
    print("## init datasets")
    ds_src = data.MultiSourceDataset(args.src, args.aug_params, batch_size=args.batch_size, val_shuffle=True, val_aug=True, domain_id=1,
                                     color=False if args.img_size[2]==1 else True, size=args.img_size[0], sample_ratio=args.sample_ratio[0])
    ds_tar = getattr(data, args.tar)(root=os.path.join('data', args.tar.lower()), batch_size=args.batch_size, val_shuffle=True, domain_id=0,
                                     color=False if args.img_size[2]==1 else True, size=args.img_size[0], sample_ratio=args.sample_ratio[1])
    ds_dom = data.DomainDataset(ds_src, ds_tar)
    print()
    

    ####
    ## base model learning
    ####
    print('## base model learning')
    ## init a base model
    mdl = getattr(model, args.model)(num_class=args.n_labels, input_shape=args.img_size)
    ## init a learner
    learner = LearnerCls(args.train, mdl)
    ## train the model
    learner.train(ds_src.train, ds_tar.val if args.cheatkey else ds_src.val, ds_tar.test)    
    ## test the model
    learner.test(ds_tar.test, ld_name=args.tar, verbose=True)
    print()


    

    
def parse_args():
    ## inint a parser
    parser = argparse.ArgumentParser(description='digit dataset training')

    ## meta args
    parser.add_argument('--exp_name', required=True, type=str, help='experiment name')
    parser.add_argument('--snapshot_root', default='snapshots', type=str, help='snapshot root name')
    parser.add_argument('--cpu', action='store_true', help='use CPU')
    parser.add_argument('--cheatkey', action='store_true', help='enable cheatkey')

    ## dataset args
    parser.add_argument('--batch_size', default=100, type=int, help='batch size')
    parser.add_argument('--n_labels', default=10, type=int, help='the number of labels')
    parser.add_argument('--src', type=str, nargs='*', help='list of sources') ##TODO: how to restrict possible inputs?
    parser.add_argument('--tar', type=str, help='target') ##TODO: how to restrict possible inputs?
    parser.add_argument('--aug', type=str, nargs='*', default=[''], help='list of data augmentation') ##TODO: how to restrict possible inputs?
    parser.add_argument('--img_size', type=int, nargs=3, default=(32, 32, 3), help='image size')
    parser.add_argument('--sample_ratio', type=float, nargs=2, default=[1.0, 1.0])
    
    ## model args
    parser.add_argument('--model', default='ResNet18', type=str, help='model name')

    ## train args
    parser.add_argument('--train.find_best', action='store_true', help='find the best model')
    parser.add_argument('--train.load_final', action='store_true', help='load the final model')
    parser.add_argument('--train.optim', default='SGD', type=str, help='optimizer')
    parser.add_argument('--train.lr', default=0.01, type=float, help='learning rate')
    parser.add_argument('--train.lr_step_size', default=20, type=float, help='stepsize for step learning rate scheduler')
    parser.add_argument('--train.lr_step_decay_rate', default=0.5, type=float, help='decay rate for step learning rate scheduler')
    parser.add_argument('--train.weight_decay', type=float, default=0.0, help='L2 weight decay')
    parser.add_argument('--train.momentum', default=0.9, type=float, help='momentum')
    parser.add_argument('--train.n_epochs', default=100, type=int, help='the number of epochs')
    parser.add_argument('--train.val_period', default=1, type=int, help='validation period in epochs')

    
    args = parser.parse_args()
    args = to_tree_namespace(args)

    ## init save_root
    args.train.save_root = os.path.join(args.snapshot_root, args.exp_name + '_%s'%(args.model))    

    ## init aug parameters
    args.aug_params = []
    for a in args.aug:
        if a == 'jitter':
            args.aug_params.append([('jitter', {'brightness': 0.4, 'contrast': 0.4, 'saturation': 0.4})])
            
        elif a == 'shake':
            args.aug_params.append([('randaug', {'size': 32, 'mode': 'SHAKE'})])
            
        elif a == 'svhnspec':
            args.aug_params.append([ 
                ('intensity_flip', {}),
                ('intensity_scaling', {'min': -1.5, 'max': 1.5}),
                ('intensity_offset', {'min': -0.5, 'max': 0.5}),
                ('affine', {'std': 0.1}),
                ('translation', {'x_max': 2.0, 'y_max': 2.0}),
                ('gaussian', {'std': 0.1}),
            ])
        else:
            ##TODO: simplify
            args.aug_params.append(None)
        
    return args


if __name__ == '__main__':
    args = parse_args()
    main(args)



